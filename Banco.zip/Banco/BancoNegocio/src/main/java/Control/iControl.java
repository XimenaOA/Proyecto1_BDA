/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Control;

import Dominio.Movimientos;

/**
 *
 * @author jesus
 */
public interface iControl {
    public void Retiro(Movimientos mov, String contra);
}
